"""
Conservative numeric-claim grounding for the Self-Validating EDA Agent.

This module complements (does not replace) insight_validator.py and the
existing evidence mapper. It checks whether numeric tokens in generated
insights/recommendations can be found in the supplied evidence.

A PASS means only that all detected numeric tokens have evidence matches.
It does NOT prove that non-numeric causal, comparative, or semantic claims
are true. An unmatched number returns REVIEW rather than FAIL because a
legitimate derived statistic may not be stored verbatim in the evidence.
"""

from __future__ import annotations

import math
import re
from typing import Any


_NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])"
    r"[-+]?(?:\d{1,3}(?:,\d{3})+|\d+)?(?:\.\d+)?"
    r"(?:[eE][-+]?\d+)?"
    r"%?"
    r"(?![A-Za-z0-9_])"
)


def _to_number(token: str):
    """Convert a matched numeric token to a float; percentages stay in points."""
    cleaned = token.replace(",", "").rstrip("%")
    if not cleaned or cleaned in {"+", "-"}:
        return None
    try:
        value = float(cleaned)
    except (TypeError, ValueError, OverflowError):
        return None
    return value if math.isfinite(value) else None


def extract_numeric_claims(text: Any) -> list[dict]:
    """Extract numeric tokens from text while preserving their original form."""
    if text is None:
        return []

    source = str(text)
    claims = []
    for match in _NUMBER_PATTERN.finditer(source):
        token = match.group(0)
        value = _to_number(token)
        if value is None:
            continue
        claims.append({
            "text": token,
            "value": value,
            "start": match.start(),
            "end": match.end(),
            "is_percentage": token.endswith("%"),
        })
    return claims


def _collect_evidence_numbers(value: Any, path: str = "evidence") -> list[dict]:
    """Collect finite numeric evidence values recursively, excluding booleans."""
    found = []

    if isinstance(value, bool) or value is None:
        return found

    if isinstance(value, (int, float)):
        numeric = float(value)
        if math.isfinite(numeric):
            found.append({"value": numeric, "path": path})
        return found

    # NumPy scalar support without requiring NumPy as a dependency.
    if hasattr(value, "item") and callable(value.item):
        try:
            scalar = value.item()
        except Exception:
            scalar = value
        if scalar is not value:
            return _collect_evidence_numbers(scalar, path)

    if isinstance(value, dict):
        for key, item in value.items():
            found.extend(_collect_evidence_numbers(item, f"{path}.{key}"))
    elif isinstance(value, (list, tuple, set)):
        for index, item in enumerate(value):
            found.extend(_collect_evidence_numbers(item, f"{path}[{index}]"))

    return found


def _numbers_match(left: float, right: float, rel_tol: float, abs_tol: float) -> bool:
    return math.isclose(left, right, rel_tol=rel_tol, abs_tol=abs_tol)


def validate_text_against_evidence(
    text: Any,
    evidence: Any,
    *,
    rel_tol: float = 1e-4,
    abs_tol: float = 1e-6,
) -> dict:
    """
    Validate numeric tokens in one generated text artifact against evidence.

    Status:
      PASS   - at least one numeric claim and every claim matched evidence.
      REVIEW - no numeric claims, or one or more claims had no direct match.

    REVIEW is deliberately non-failing: derived values, rounded formatting,
    percentages, and semantic claims may need domain-specific validation.
    """
    claims = extract_numeric_claims(text)
    evidence_numbers = _collect_evidence_numbers(evidence)

    matched = []
    unmatched = []

    for claim in claims:
        candidates = [
            item for item in evidence_numbers
            if _numbers_match(
                claim["value"],
                item["value"],
                rel_tol=rel_tol,
                abs_tol=abs_tol,
            )
        ]
        if candidates:
            matched.append({
                **claim,
                "matched_evidence_paths": [item["path"] for item in candidates[:5]],
            })
        else:
            unmatched.append(claim)

    if not claims:
        status = "REVIEW"
        reason = "No numeric claims were found; semantic claims require separate validation."
    elif unmatched:
        status = "REVIEW"
        reason = (
            "One or more numeric claims did not match a numeric value in the supplied "
            "evidence. Review derived values, rounding, percentages, and claim context."
        )
    else:
        status = "PASS"
        reason = (
            "Every detected numeric token matched at least one numeric evidence value. "
            "This does not validate non-numeric or causal claims."
        )

    return {
        "status": status,
        "pass": status == "PASS",
        "validation_scope": "numeric_token_to_evidence_match_only",
        "numeric_claim_count": len(claims),
        "matched_claim_count": len(matched),
        "unmatched_claim_count": len(unmatched),
        "matched_claims": matched,
        "unmatched_claims": unmatched,
        "evidence_numeric_value_count": len(evidence_numbers),
        "reason": reason,
        "limitations": [
            "A numeric match does not prove that the number is used in the correct sentence context.",
            "Non-numeric claims, causality, and recommendation logic are not validated here.",
            "Percentages are compared as displayed numeric points, not converted to proportions.",
            "Derived values not stored directly in evidence may receive REVIEW.",
        ],
    }


def validate_insight_and_recommendation(
    insight: Any,
    recommendation: Any,
    evidence: Any,
) -> dict:
    """Validate insight and recommendation numeric claims independently."""
    insight_result = validate_text_against_evidence(insight, evidence)
    recommendation_result = validate_text_against_evidence(recommendation, evidence)

    return {
        "insight": insight_result,
        "recommendation": recommendation_result,
        "overall": "PASS" if (
            insight_result["status"] == "PASS"
            and recommendation_result["status"] == "PASS"
        ) else "REVIEW",
        "scope": "numeric_claim_grounding_only",
    }
