"""
Independent validation of generated recommendations against validated evidence.

This module is deliberately conservative:
- FAIL: the recommendation generator/evidence explicitly reports failure.
- PASS: every numeric claim can be matched to evidence or a deterministic
  arithmetic derivation from the evidence.
- REVIEW: a claim cannot be independently grounded with the supplied evidence.

It does not use an LLM and never invents replacement values.
"""
import math
import re


_NUMBER_RE = re.compile(r"(?<![A-Za-z])[-+]?\d[\d,]*(?:\.\d+)?%?")


def _finite_float(value):
    try:
        number = float(str(value).replace(",", "").replace("%", "").strip())
        return number if math.isfinite(number) else None
    except (TypeError, ValueError, OverflowError):
        return None


def _walk_numbers(value, path="evidence", depth=0):
    """Collect finite numeric values and their paths from nested evidence."""
    if depth > 12:
        return []
    found = []
    if isinstance(value, bool) or value is None:
        return found
    if isinstance(value, dict):
        for key, child in value.items():
            found.extend(_walk_numbers(child, f"{path}.{key}", depth + 1))
    elif isinstance(value, (list, tuple, set)):
        for index, child in enumerate(value):
            found.extend(_walk_numbers(child, f"{path}[{index}]", depth + 1))
    else:
        number = _finite_float(value)
        if number is not None:
            found.append((number, path))
    return found


def _approximately_equal(left, right):
    return abs(left - right) <= max(0.02, abs(right) * 0.0002)


def _recommendation_text(recommendation):
    if isinstance(recommendation, dict):
        return str(recommendation.get("recommendation", "") or "")
    return str(recommendation or "")


def _derived_differences(numbers):
    """Return pairwise differences for numeric evidence, bounded for safety."""
    values = [item[0] for item in numbers]
    # A bounded pairwise set supports common grouped-comparison statements.
    if len(values) > 250:
        return []
    return [abs(values[i] - values[j])
            for i in range(len(values))
            for j in range(i + 1, len(values))]


def validate_recommendation(
    recommendation,
    evidence,
    analysis_type=None,
    primary_result=None,
    claim_evidence_validation=None,
):
    """
    Independently check recommendation presence, evidence status, structured
    basis fields, and numeric claims in recommendation text.
    """
    text = _recommendation_text(recommendation)
    checks = []
    reasons = []

    if not text.strip():
        return {
            "status": "FAIL",
            "overall": "FAIL",
            "pass": False,
            "total_numeric_claims": 0,
            "verified_numeric_claims": 0,
            "unverified_numeric_claims": 0,
            "checks": [{"name": "recommendation_presence", "status": "FAIL",
                        "reason": "Recommendation is empty."}],
            "reasons": ["Recommendation is empty."],
        }

    if isinstance(recommendation, dict):
        generator_status = str(recommendation.get("status", "")).upper()
        if generator_status in {"FAIL", "FAILED", "ERROR", "UNSUPPORTED"}:
            return {
                "status": "FAIL", "overall": "FAIL", "pass": False,
                "total_numeric_claims": 0, "verified_numeric_claims": 0,
                "unverified_numeric_claims": 0,
                "checks": [{"name": "generator_status", "status": "FAIL",
                            "reason": str(recommendation.get("reason", generator_status))}],
                "reasons": [str(recommendation.get("reason", generator_status))],
            }

    if not isinstance(evidence, dict) or str(evidence.get("status", "")).upper() != "PASS":
        return {
            "status": "FAIL", "overall": "FAIL", "pass": False,
            "total_numeric_claims": 0, "verified_numeric_claims": 0,
            "unverified_numeric_claims": 0,
            "checks": [{"name": "evidence_status", "status": "FAIL",
                        "reason": "Recommendation evidence is missing or not PASS."}],
            "reasons": ["Recommendation evidence is missing or not PASS."],
        }

    evidence_numbers = _walk_numbers(evidence)
    evidence_values = [item[0] for item in evidence_numbers]
    derived_differences = _derived_differences(evidence_numbers)
    numeric_claims = []
    for match in _NUMBER_RE.finditer(text):
        raw = match.group(0)
        number = _finite_float(raw)
        if number is not None:
            numeric_claims.append({"text": raw, "value": number})

    verified = []
    unverified = []
    for claim in numeric_claims:
        value = claim["value"]
        direct = next(
            (path for actual, path in evidence_numbers
             if _approximately_equal(value, actual)),
            None,
        )
        derived = any(_approximately_equal(value, actual)
                      for actual in derived_differences)
        if direct:
            verified.append({**claim, "matched_evidence_path": direct})
        elif derived:
            verified.append({**claim, "matched_evidence_path": "deterministic_pairwise_difference"})
        else:
            unverified.append(claim)

    checks.append({
        "name": "numeric_claim_grounding",
        "status": "PASS" if not unverified else "REVIEW",
        "total": len(numeric_claims),
        "verified": len(verified),
        "unverified": len(unverified),
        "verified_claims": verified,
        "unverified_claims": unverified,
    })

    # Validate structured recommendation basis when present. A basis field
    # must agree with a corresponding evidence field if that field exists.
    basis = recommendation.get("basis") if isinstance(recommendation, dict) else None
    basis_mismatches = []
    if isinstance(basis, dict):
        for key in ("metric", "analysis_type", "filter_column", "filter_value",
                    "category", "top_category", "group_column"):
            claimed = basis.get(key)
            if claimed is None:
                continue
            actual_candidates = []
            for container in (evidence, evidence.get("evidence", {}),
                              evidence.get("supporting_result", {})):
                if isinstance(container, dict) and key in container:
                    actual_candidates.append(container[key])
            if actual_candidates and not any(
                str(claimed).strip().casefold() == str(actual).strip().casefold()
                for actual in actual_candidates
            ):
                basis_mismatches.append({
                    "field": key, "claimed": claimed,
                    "evidence_values": actual_candidates,
                })

        for key in ("value", "mean", "correlation"):
            claimed = _finite_float(basis.get(key))
            if claimed is None:
                continue
            candidate_values = []
            for container in (evidence, evidence.get("evidence", {}),
                              evidence.get("supporting_result", {})):
                if isinstance(container, dict):
                    for candidate_key in (key, "mean_value", "mean", "value", "correlation"):
                        if candidate_key in container:
                            number = _finite_float(container[candidate_key])
                            if number is not None:
                                candidate_values.append(number)
            if candidate_values and not any(_approximately_equal(claimed, x)
                                            for x in candidate_values):
                basis_mismatches.append({
                    "field": key, "claimed": claimed,
                    "evidence_values": candidate_values,
                })

    checks.append({
        "name": "structured_basis_consistency",
        "status": "FAIL" if basis_mismatches else "PASS",
        "mismatches": basis_mismatches,
    })

    if basis_mismatches:
        reasons.append("Structured recommendation basis contradicts available evidence.")

    # Existing claim grounding is retained as an additional signal. Do not
    # mistake absent/legacy fields for a pass.
    if isinstance(claim_evidence_validation, dict):
        claim_status = str(
            claim_evidence_validation.get("overall")
            or claim_evidence_validation.get("status")
            or ""
        ).upper()
        try:
            failed_claim_count = int(
                claim_evidence_validation.get("failed_claims", 0) or 0
            )
        except (TypeError, ValueError, OverflowError):
            failed_claim_count = 1
        failed = (
            claim_status in {"FAIL", "FAILED"}
            or claim_evidence_validation.get("pass") is False
            or failed_claim_count > 0
        )
        checks.append({
            "name": "existing_claim_evidence_validation",
            "status": "FAIL" if failed else ("PASS" if claim_status == "PASS" or claim_evidence_validation.get("pass") is True else "REVIEW"),
        })
        if failed:
            reasons.append("Existing claim/evidence grounding reported a failure.")

    hard_fail = bool(basis_mismatches) or any(
        item["status"] == "FAIL" for item in checks
    )
    needs_review = bool(unverified) or any(
        item["status"] == "REVIEW" for item in checks
    )

    status = "FAIL" if hard_fail else ("REVIEW" if needs_review else "PASS")
    if unverified:
        reasons.append("One or more numerical statements could not be independently grounded.")
    if not numeric_claims:
        checks.append({
            "name": "numeric_claim_presence",
            "status": "PASS",
            "reason": "No numerical claims were made; recommendation remains subject to evidence review.",
        })

    return {
        "status": status,
        "overall": status,
        "pass": status == "PASS",
        "analysis_type": analysis_type,
        "total_numeric_claims": len(numeric_claims),
        "verified_numeric_claims": len(verified),
        "unverified_numeric_claims": len(unverified),
        "checks": checks,
        "reasons": reasons,
    }
